/*
 * Template JAVA User Interface
 * =============================
 *
 * Database Management Systems
 * Department of Computer Science &amp; Engineering
 * University of California - Riverside
 *
 * Target DBMS: 'Postgres'
 *
 */


import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.util.ArrayList;
import java.lang.Math;

/**
 * This class defines a simple embedded SQL utility class that is designed to
 * work with PostgreSQL JDBC drivers.
 *
 */
public class Amazon {

   // reference to physical database connection.
   private Connection _connection = null;

   // handling the keyboard inputs through a BufferedReader
   // This variable can be global for convenience.
   static BufferedReader in = new BufferedReader(
                                new InputStreamReader(System.in));

   /**
    * Creates a new instance of Amazon store
    *
    * @param hostname the MySQL or PostgreSQL server hostname
    * @param database the name of the database
    * @param username the user name used to login to the database
    * @param password the user login password
    * @throws java.sql.SQLException when failed to make a connection.
    */
   public Amazon(String dbname, String dbport, String user, String passwd) throws SQLException {

      System.out.print("Connecting to database...");
      try{
         // constructs the connection URL
         String url = "jdbc:postgresql://localhost:" + dbport + "/" + dbname;
         System.out.println ("Connection URL: " + url + "\n");

         // obtain a physical connection
         this._connection = DriverManager.getConnection(url, user, passwd);
         System.out.println("Done");
      }catch (Exception e){
         System.err.println("Error - Unable to Connect to Database: " + e.getMessage() );
         System.out.println("Make sure you started postgres on this machine");
         System.exit(-1);
      }//end catch
   }//end Amazon

   // Method to calculate euclidean distance between two latitude, longitude pairs. 
   public double calculateDistance (double lat1, double long1, double lat2, double long2){
      double t1 = (lat1 - lat2) * (lat1 - lat2);
      double t2 = (long1 - long2) * (long1 - long2);
      return Math.sqrt(t1 + t2); 
   }
   /**
    * Method to execute an update SQL statement.  Update SQL instructions
    * includes CREATE, INSERT, UPDATE, DELETE, and DROP.
    *
    * @param sql the input SQL string
    * @throws java.sql.SQLException when update failed
    */
   public void executeUpdate (String sql) throws SQLException {
      // creates a statement object
      Statement stmt = this._connection.createStatement ();

      // issues the update instruction
      stmt.executeUpdate (sql);

      // close the instruction
      stmt.close ();
   }//end executeUpdate

   /**
    * Method to execute an input query SQL instruction (i.e. SELECT).  This
    * method issues the query to the DBMS and outputs the results to
    * standard out.
    *
    * @param query the input query string
    * @return the number of rows returned
    * @throws java.sql.SQLException when failed to execute the query
    */
   public int executeQueryAndPrintResult (String query) throws SQLException {
      // creates a statement object
      Statement stmt = this._connection.createStatement ();

      // issues the query instruction
      ResultSet rs = stmt.executeQuery (query);

      /*
       ** obtains the metadata object for the returned result set.  The metadata
       ** contains row and column info.
       */
      ResultSetMetaData rsmd = rs.getMetaData ();
      int numCol = rsmd.getColumnCount ();
      int rowCount = 0;

      // iterates through the result set and output them to standard out.
      boolean outputHeader = true;
      while (rs.next()){
		 if(outputHeader){
			for(int i = 1; i <= numCol; i++){
			System.out.print(rsmd.getColumnName(i) + "\t");
			}
			System.out.println();
			outputHeader = false;
		 }
         for (int i=1; i<=numCol; ++i)
            System.out.print (rs.getString (i) + "\t");
         System.out.println ();
         ++rowCount;
      }//end while
      stmt.close ();
      return rowCount;
   }//end executeQuery

   /**
    * Method to execute an input query SQL instruction (i.e. SELECT).  This
    * method issues the query to the DBMS and returns the results as
    * a list of records. Each record in turn is a list of attribute values
    *
    * @param query the input query string
    * @return the query result as a list of records
    * @throws java.sql.SQLException when failed to execute the query
    */
   public List<List<String>> executeQueryAndReturnResult (String query) throws SQLException {
      // creates a statement object
      Statement stmt = this._connection.createStatement ();

      // issues the query instruction
      ResultSet rs = stmt.executeQuery (query);

      /*
       ** obtains the metadata object for the returned result set.  The metadata
       ** contains row and column info.
       */
      ResultSetMetaData rsmd = rs.getMetaData ();
      int numCol = rsmd.getColumnCount ();
      int rowCount = 0;

      // iterates through the result set and saves the data returned by the query.
      boolean outputHeader = false;
      List<List<String>> result  = new ArrayList<List<String>>();
      while (rs.next()){
        List<String> record = new ArrayList<String>();
		for (int i=1; i<=numCol; ++i)
			record.add(rs.getString (i));
        result.add(record);
      }//end while
      stmt.close ();
      return result;
   }//end executeQueryAndReturnResult

   /**
    * Method to execute an input query SQL instruction (i.e. SELECT).  This
    * method issues the query to the DBMS and returns the number of results
    *
    * @param query the input query string
    * @return the number of rows returned
    * @throws java.sql.SQLException when failed to execute the query
    */
   public int executeQuery (String query) throws SQLException {
       // creates a statement object
       Statement stmt = this._connection.createStatement ();

       // issues the query instruction
       ResultSet rs = stmt.executeQuery (query);

       int rowCount = 0;

       // iterates through the result set and count nuber of results.
       while (rs.next()){
          rowCount++;
       }//end while
       stmt.close ();
       return rowCount;
   }

   /**
    * Method to fetch the last value from sequence. This
    * method issues the query to the DBMS and returns the current
    * value of sequence used for autogenerated keys
    *
    * @param sequence name of the DB sequence
    * @return current value of a sequence
    * @throws java.sql.SQLException when failed to execute the query
    */
   public int getCurrSeqVal(String sequence) throws SQLException {
	Statement stmt = this._connection.createStatement ();

	ResultSet rs = stmt.executeQuery (String.format("Select currval('%s')", sequence));
	if (rs.next())
		return rs.getInt(1);
	return -1;
   }

   /**
    * Method to close the physical connection if it is open.
    */
   public void cleanup(){
      try{
         if (this._connection != null){
            this._connection.close ();
         }//end if
      }catch (SQLException e){
         // ignored.
      }//end try
   }//end cleanup

   /**
    * The main execution method
    *
    * @param args the command line arguments this inclues the <mysql|pgsql> <login file>
    */
   public static void main (String[] args) {
      if (args.length != 3) {
         System.err.println (
            "Usage: " +
            "java [-classpath <classpath>] " +
            Amazon.class.getName () +
            " <dbname> <port> <user>");
         return;
      }//end if

      Greeting();
      Amazon esql = null;
      try{
         // use postgres JDBC driver.
         Class.forName ("org.postgresql.Driver").newInstance ();
         // instantiate the Amazon object and creates a physical
         // connection.
         String dbname = args[0];
         String dbport = args[1];
         String user = args[2];
         esql = new Amazon (dbname, dbport, user, "");

         boolean keepon = true;
         while(keepon) {
            // These are sample SQL statements
            System.out.println("MAIN MENU");
            System.out.println("---------");
            System.out.println("1. Create user");
            System.out.println("2. Log in");
            System.out.println("9. < EXIT");
            String authorisedUser = null;
            switch (readChoice()){
               case 1: CreateUser(esql); break;
               case 2: authorisedUser = LogIn(esql); break;
               case 9: keepon = false; break;
               default : System.out.println("Unrecognized choice!"); break;
            }//end switch
            if (authorisedUser != null) {
              boolean usermenu = true;
              while(usermenu) {
                System.out.println();
                System.out.println("MAIN MENU");
                System.out.println("---------");
                System.out.println();

                System.out.println("--- CUSTOMERS ---");
                System.out.println("1. View Stores within 30 miles");
                System.out.println("2. View Product List");
                System.out.println("3. Place a Order");
                System.out.println("4. View 5 recent orders");
               
                //the following functionalities basically used by managers
                System.out.println();
                System.out.println("--- MANAGERS ---");
                System.out.println("5. Update Product");
                System.out.println("6. View 5 recent Product Updates Info");
                System.out.println("7. View 5 Popular Items");
                System.out.println("8. View 5 Popular Customers");
                System.out.println("9. Place Product Supply Request to Warehouse");
                System.out.println("10. View order information of all stores");
                

                System.out.println(".........................");
                System.out.println("20. Log out");
                System.out.println();
                switch (readChoice()){
                   case 1: viewStores(esql); break;
                   case 2: viewProducts(esql); break;
                   case 3: placeOrder(esql); break;
                   case 4: viewRecentOrders(esql); break;
                   case 5: updateProduct(esql); break;
                   case 6: viewRecentUpdates(esql); break;
                   case 7: viewPopularProducts(esql); break;
                   case 8: viewPopularCustomers(esql); break;
                   case 9: placeProductSupplyRequests(esql); break;
                   case 10: viewOrderInfo(esql); break;

                   case 20: usermenu = false; break;
                   default : System.out.println("Unrecognized choice!"); break;
                }
              }
            }
         }//end while
      }catch(Exception e) {
         System.err.println (e.getMessage ());
      }finally{
         // make sure to cleanup the created table and close the connection.
         try{
            if(esql != null) {
               System.out.print("Disconnecting from database...");
               esql.cleanup ();
               System.out.println("Done\n\nBye !");
            }//end if
         }catch (Exception e) {
            // ignored.
         }//end try
      }//end try
   }//end main

   public static void Greeting(){
      System.out.println(
         "\n\n*******************************************************\n" +
         "              User Interface      	               \n" +
         "*******************************************************\n");
   }//end Greeting

   /*
    * Reads the users choice given from the keyboard
    * @int
    **/
   public static int readChoice() {
      int input;
      // returns only if a correct value is given.
      do {
         System.out.print("Please make your choice: ");
         try { // read the integer, parse it and break.
            input = Integer.parseInt(in.readLine());
            break;
         }catch (Exception e) {
            System.out.println("Your input is invalid!");
            continue;
         }//end try
      }while (true);
      return input;
   }//end readChoice

   /*
    * Creates a new user
    **/
   public static void CreateUser(Amazon esql){
      try{
         System.out.print("\tEnter name: ");
         String name = in.readLine();
         System.out.print("\tEnter password: ");
         String password = in.readLine();
         System.out.print("\tEnter latitude: ");   
         String latitude = in.readLine();       //enter lat value between [0.0, 100.0]
         System.out.print("\tEnter longitude: ");  //enter long value between [0.0, 100.0]
         String longitude = in.readLine();
         
         String type="Customer";

			String query = String.format("INSERT INTO USERS (name, password, latitude, longitude, type) VALUES ('%s','%s', %s, %s,'%s')", name, password, latitude, longitude, type);

         esql.executeUpdate(query);
         System.out.println ("User successfully created!");
      }catch(Exception e){
         System.err.println (e.getMessage ());
      }
   }//end CreateUser


   /*
    * Check log in credentials for an existing user
    * @return User login or null is the user does not exist
    **/
   public static String LogIn(Amazon esql){
      try{
         System.out.print("\tEnter name: ");
         String name = in.readLine();
         System.out.print("\tEnter password: ");
         String password = in.readLine();

         String query = String.format("SELECT * FROM USERS WHERE name = '%s' AND password = '%s'", name, password);
         int userNum = esql.executeQuery(query);
	 if (userNum > 0)
		return name;
         return null;
      }catch(Exception e){
         System.err.println (e.getMessage ());
         return null;
      }
   }//end

// Rest of the functions definition go in here
public static void viewStores(Amazon esql) {
   try {
       System.out.print("\tEnter your latitude: ");
       double userLat = Double.parseDouble(in.readLine());
       System.out.print("\tEnter your longitude: ");
       double userLong = Double.parseDouble(in.readLine());
       String query = "SELECT * FROM Store;";
       List<List<String>> stores = esql.executeQueryAndReturnResult(query);
       for (List<String> store : stores) {
           double storeLat = Double.parseDouble(store.get(2));
           double storeLong = Double.parseDouble(store.get(3));
           double distance = esql.calculateDistance(userLat, userLong, storeLat, storeLong);
           if (distance <= 30.0) {
               System.out.println("Store ID: " + store.get(0));
           }
       }
   } catch (Exception e) {
       System.err.println(e.getMessage());
   }
  }
  public static void viewProducts(Amazon esql) {
  try {
     System.out.print("\tEnter store ID: ");
     int storeID = Integer.parseInt(in.readLine());
     String query = String.format("SELECT p.productName, p.numberOfUnits, p.pricePerUnit FROM Product p JOIN Store s ON p.storeID = s.storeID WHERE p.storeID = %d", storeID);
     esql.executeQueryAndPrintResult(query);
 } catch (Exception e) {
     System.err.println(e.getMessage());
 }
}
  public static void placeOrder(Amazon esql) {
     try {
         System.out.print("\tEnter your store ID: ");
         int storeID = Integer.parseInt(in.readLine());
         System.out.print("\tEnter product name: ");
         String productName = in.readLine();
         System.out.print("\tEnter number of units: ");
         int unitsOrdered = Integer.parseInt(in.readLine());
         String query = String.format("INSERT INTO Orders(storeID, productName, unitsOrdered) VALUES (%d, '%s', %d)", storeID, productName, unitsOrdered);
         esql.executeUpdate(query);
         System.out.println("Order placed successfully!");
     } catch (Exception e) {
         System.err.println(e.getMessage());
     }
 }

   
  
   /* 5 of his/her recent orders from the Orders table
   storeID, productName, number of units ordered and date ordered */ 

   public static void viewRecentOrders(Amazon esql) {
      try {
         System.out.println("Please enter your name and password to view your recent orders.");
         System.out.println();
         System.out.print("\tEnter name: ");
         String name = in.readLine();
         System.out.print("\tEnter password: ");
         String password = in.readLine();
         System.out.println();
         System.out.println("Getting your user ID...");
         System.out.println();

         String getUser = String.format("SELECT U.userID FROM Users U WHERE U.name = '%s' AND U.password = '%s'", name, password);
         System.out.println();
         int userID = esql.executeQueryAndPrintResult(getUser);

         System.out.print("\tEnter the user ID: ");
         String enterID = in.readLine();

         String output = String.format("SELECT DISTINCT O.storeID, O.productName, O.unitsOrdered, O.orderTime FROM Orders O JOIN Users U ON O.customerID = '%s' ORDER BY O.orderTime DESC LIMIT 5", enterID);
         List<List<String>> orders = esql.executeQueryAndReturnResult(output);

         System.out.println("Store ID\tProduct Name\tUnits Ordered\tDate Ordered");

         for (List<String> row : orders) {
            for (String value : row) {
               System.out.print(value + "\t");
            }
            System.out.println();
         }
         System.out.println();
      }
      catch(Exception e) {
      System.err.println(e.getMessage());
      }
   }


   /*
    1. Ask user for name and password to get userID
    2. Let user enter ID
    3. Show list of stores they manage
    4. Prompt user to enter storeID
    5. Display Product table 
    6. Prompt user to choose product name
    7. Ask if they want to update number of units (yes or no) and priceperunit (yes or no)
    8. Execute update queries
    9. Insert update entry into productUpdates
    */
   public static void updateProduct(Amazon esql) {
      try {
         System.out.println("Please enter your name and password to update product(s).");
         System.out.println();
         System.out.print("\tEnter name: ");
         String name = in.readLine();
         System.out.print("\tEnter password: ");
         String password = in.readLine();
         System.out.println();
         System.out.println("Getting your user ID...");
         System.out.println();

         String getUser = String.format("SELECT U.userID FROM Users U WHERE U.name = '%s' AND U.password = '%s'", name, password);
         System.out.println();

         String getType = String.format("SELECT U.type FROM Users U WHERE U.name = '%s' AND U.password = '%s'", name, password);
         List<List<String>> userType = esql.executeQueryAndReturnResult(getType);

         for (List<String> row : userType) {
            for (String value : row) {
                if (value.trim().equals("customer")) {
                  System.out.println("You do not have access to this function as a customer.");
                  return; 
                }
            }
        }

         int userID = esql.executeQueryAndPrintResult(getUser);

         List<List<String>> storeManaged = new ArrayList<>();
         
         
         System.out.print("\tEnter the user ID: ");
         String enterID = in.readLine(); 

         String output = "SELECT DISTINCT * FROM Store S ORDER BY S.storeID ASC"; 
         String output2 = String.format("SELECT DISTINCT * FROM Store S WHERE S.managerID = '%s'", enterID);

         if (enterID.equals("1")) {
            storeManaged = esql.executeQueryAndReturnResult(output);
         }
         else {
            storeManaged = esql.executeQueryAndReturnResult(output2);
         }
         
         System.out.println();
         System.out.println("List of stores");
         System.out.println();
         System.out.println("Store ID\tLatitude\t\tLongitude\t\tManager ID\tDate Established");
         for (List<String> row : storeManaged) {
            for (String value : row) {
               System.out.print(value + "\t\t");
            }
            System.out.println();
         }

         System.out.println();

         System.out.print("Enter the store ID to complete updates: ");
         String enterStore = in.readLine();

         String showStore = String.format("SELECT DISTINCT * FROM Product P WHERE P.storeID = '%s' ORDER BY P.numberOfUnits ASC", enterStore);
         List<List<String>> stores = esql.executeQueryAndReturnResult(showStore);
         System.out.println();
         System.out.println("List of products in store");
         System.out.println();
         System.out.println("Store ID\tProduct Name\t\tNumber of Units\t\tPrice Per Unit");
         for (List<String> row : stores) {
            for (String value : row) {
               System.out.print(value + "\t\t");
            }
            System.out.println();
         }

         System.out.print("Enter the product name to update: ");
         String pname = in.readLine();
         String showProd = String.format("SELECT * FROM Product P WHERE P.productName = '%s'", pname);
         List<List<String>> products = esql.executeQueryAndReturnResult(showProd);

         //Updated numberOfUnits
         System.out.print("Update the number of units? yes or no");
         System.out.println();
         String option = in.readLine();
         if ("yes".equals(option)) {
            System.out.print("Enter the new number of units: ");
            String newUnits = in.readLine();
            String updateUnits = String.format("UPDATE Product P SET numberOfUnits = '%s' WHERE P.storeID = '%s' AND P.productName = '%s'", newUnits, enterStore, pname); 

            esql.executeUpdate(updateUnits);
            System.out.println ("Successfully updated number of units for " + pname);

            //Show update 
            String newUpdate = String.format("SELECT DISTINCT * FROM Product P WHERE P.storeID = '%s' ORDER BY P.numberOfUnits ASC", enterStore);
            System.out.println();
            System.out.println("Products");
            System.out.println();
            System.out.println("Store ID\tProduct Name\t\tNumber of Units\t\tPrice Per Unit");
            List<List<String>> updatedProduct = esql.executeQueryAndReturnResult(newUpdate);
            for (List<String> row : updatedProduct) {
               for (String value : row) {
                  System.out.print(value + "\t\t");
               }
               System.out.println();
            }
         }

         System.out.println();

         //Update pricePerUnit
         System.out.print("Update the price per unit? yes or no");
         System.out.println();
         String price_option = in.readLine();
         if ("yes".equals(price_option)) {
            System.out.print("Enter the new price: ");
            String newPrice = in.readLine();
            String updatePrice = String.format("UPDATE Product P SET pricePerUnit = '%s' WHERE P.storeID = '%s' AND P.productName = '%s'", newPrice, enterStore, pname); 

            esql.executeUpdate(updatePrice);
            System.out.println ("Successfully updated price per unit for " + pname);

            String newPriceUpdate = String.format("SELECT DISTINCT * FROM Product P WHERE P.storeID = '%s' ORDER BY P.pricePerUnit ASC", enterStore);
            System.out.println();
            System.out.println("Products");
            System.out.println();
            System.out.println("Store ID\tProduct Name\t\tNumber of Units\t\tPrice Per Unit");
            List<List<String>> updatedPrice = esql.executeQueryAndReturnResult(newPriceUpdate);
            for (List<String> row : updatedPrice) {
               for (String value : row) {
                  System.out.print(value + "\t\t");
               }
               System.out.println();
            }
         }

         System.out.println();
         

         //Update productUpdates
         String updateRecord = String.format("INSERT INTO ProductUpdates (managerID, storeID, productName, updatedOn) VALUES ('%s', '%s', '%s', CURRENT_TIMESTAMP)", enterID, enterStore, pname);
         esql.executeUpdate(updateRecord);

         System.out.print("ProductUpdates table has also been updated.");
         System.out.println();
         
      } catch(Exception e) {
            System.err.println(e.getMessage());
            }
   
}  
   
   public static void viewRecentUpdates(Amazon esql) {
      try {
         //Show 5 recent productUpdates
         System.out.println("Please enter your name and password to see recent updates of your store(s).");
         System.out.println();
         System.out.print("\tEnter name: ");
         String name = in.readLine();
         System.out.print("\tEnter password: ");
         String password = in.readLine();
         System.out.println();
         System.out.println("Getting your user ID...");
         System.out.println();

         String getUser = String.format("SELECT U.userID FROM Users U WHERE U.name = '%s' AND U.password = '%s'", name, password);
         System.out.println();

         String getType = String.format("SELECT U.type FROM Users U WHERE U.name = '%s' AND U.password = '%s'", name, password);
         List<List<String>> userType = esql.executeQueryAndReturnResult(getType);

         for (List<String> row : userType) {
            for (String value : row) {
                if (value.trim().equals("customer")) {
                  System.out.println("You do not have access to this function as a customer.");
                  return; 
                }
            }
        }

         int userID = esql.executeQueryAndPrintResult(getUser);

         System.out.print("\tEnter the user ID: ");
         String enterID = in.readLine();
         System.out.println();

         String output = String.format("SELECT DISTINCT * FROM Store S WHERE S.managerID = '%s'", enterID);
         String output2 = "SELECT DISTINCT * FROM Store S ORDER BY S.storeID ASC";

         List<List<String>> storeManaged = new ArrayList<>();

         if (enterID.equals("1")) {
            storeManaged = esql.executeQueryAndReturnResult(output2);
         }
         else {
            storeManaged = esql.executeQueryAndReturnResult(output);
         }

         System.out.println();
         System.out.println("List of stores");
         System.out.println();
         System.out.println("Store ID\tLatitude\t\tLongitude\t\tManager ID\tDate Established");
         for (List<String> row : storeManaged) {
            for (String value : row) {
               System.out.print(value + "\t\t");
            }
            System.out.println();
         }
         System.out.println();

         System.out.print("Enter the store ID to see a list of records of product updates: ");
         String enterStore = in.readLine();

         System.out.println();

         String newProductUpdate = String.format("SELECT DISTINCT * FROM ProductUpdates P WHERE P.storeID = '%s' AND P.managerID = '%s' ORDER BY P.updatedOn DESC LIMIT 5", enterStore, enterID);
            System.out.println();
            System.out.println("ProductUpdates Table");
            System.out.println();
            System.out.println("UpdateNum\tManagerID\tStoreID\t\tProductName\tUpdatedOn");
            List<List<String>> updatedTable = esql.executeQueryAndReturnResult(newProductUpdate);
            for (List<String> row : updatedTable) {
               for (String value : row) {
                  System.out.print(value + "\t\t");
               }
               System.out.println();
            }
      } catch(Exception e) {
         System.err.println(e.getMessage());
         }
   }

  
   /*1. Prompt user input to enter name and password
    * 2. Let user enter their id
    3. Select the productName of 5 highest product from orders table using count(), order by desc 
   */
   public static void viewPopularProducts(Amazon esql) {
      try {
         System.out.println("Please enter your name and password to see the five most popular products.");
         System.out.println();
         System.out.print("\tEnter name: ");
         String name = in.readLine();
         System.out.print("\tEnter password: ");
         String password = in.readLine();
         System.out.println();
         System.out.println("Getting your user ID...");
         System.out.println();

         String getUser = String.format("SELECT U.userID FROM Users U WHERE U.name = '%s' AND U.password = '%s'", name, password);
         System.out.println();

         String getType = String.format("SELECT U.type FROM Users U WHERE U.name = '%s' AND U.password = '%s'", name, password);
         List<List<String>> userType = esql.executeQueryAndReturnResult(getType);

         for (List<String> row : userType) {
            for (String value : row) {
                if (value.trim().equals("customer")) {
                  System.out.println("You do not have access to this function as a customer.");
                  return; 
                }
            }
        }

         int userID = esql.executeQueryAndPrintResult(getUser);

         System.out.print("\tEnter the user ID: ");
         String enterID = in.readLine();
         System.out.println();

         String output = String.format("SELECT DISTINCT O.productName, COUNT(*) AS total_orders FROM Store S, Orders O WHERE S.managerID = '%s' AND O.storeID = S.storeID GROUP BY O.productName ORDER BY total_orders DESC LIMIT 5", enterID);
         List<List<String>> popularProducts = esql.executeQueryAndReturnResult(output);
         System.out.println();
         System.out.println("List of the 5 most popular products");
         System.out.println();
         System.out.println("Product Name\tNumber of Orders");
         for (List<String> row : popularProducts) {
            for (String value : row) {
               System.out.print(value + "\t\t");
            }
            System.out.println();
         }
         System.out.println();


      } catch(Exception e) {
         System.err.println(e.getMessage());
         }
   }



 /*1. Prompt user input to enter name and password
    * 2. Let user enter their id
    3. Select the users of 5 highest order placements from orders table using count(), order by desc 
   */
   public static void viewPopularCustomers(Amazon esql) {
      try {
         System.out.println("Please enter your name and password to see the five most popular customers in your store(s).");
         System.out.println();
         System.out.print("\tEnter name: ");
         String name = in.readLine();
         System.out.print("\tEnter password: ");
         String password = in.readLine();
         System.out.println();
         System.out.println("Getting your user ID...");
         System.out.println();

         String getUser = String.format("SELECT U.userID FROM Users U WHERE U.name = '%s' AND U.password = '%s'", name, password);
         System.out.println();

         String getType = String.format("SELECT U.type FROM Users U WHERE U.name = '%s' AND U.password = '%s'", name, password);
         List<List<String>> userType = esql.executeQueryAndReturnResult(getType);

         for (List<String> row : userType) {
            for (String value : row) {
                if (value.trim().equals("customer")) {
                  System.out.println("You do not have access to this function as a customer.");
                  return; 
                }
            }
        }

         int userID = esql.executeQueryAndPrintResult(getUser);

         System.out.print("\tEnter the user ID: ");
         String enterID = in.readLine();
         System.out.println();

         String output = String.format("SELECT DISTINCT U.name, COUNT(*) AS total_orders FROM Store S, Orders O, Users U WHERE S.managerID = '%s' AND O.customerID = U.userID AND U.type = 'customer' GROUP BY U.name ORDER BY total_orders DESC LIMIT 5", enterID);
         List<List<String>> popularCustomers = esql.executeQueryAndReturnResult(output);
         System.out.println();
         System.out.println("List of the 5 popular customers who placed the most orders in your store(s)");
         System.out.println();
         System.out.println("Customer Name\t\tNumber of Orders");
         for (List<String> row : popularCustomers) {
            for (String value : row) {
               System.out.print(value + "\t");
            }
            System.out.println();
         }
         System.out.println();

      } catch(Exception e) {
         System.err.println(e.getMessage());
         }



   }


   /*
    * need to input storeID, productName, number of units needed,
      and warehouseID of the warehouse which will supply the supply request
      *need to update product table 
      *need to update productsupplyrequest
    */
   public static void placeProductSupplyRequests(Amazon esql) {
      try {
         System.out.println("Please enter your name and password to begin a supply request.");
         System.out.println();
         System.out.print("\tEnter name: ");
         String name = in.readLine();
         System.out.print("\tEnter password: ");
         String password = in.readLine();
         System.out.println();
         System.out.println("Getting your user ID...");
         System.out.println();

         String getUser = String.format("SELECT U.userID FROM Users U WHERE U.name = '%s' AND U.password = '%s'", name, password);
         System.out.println();

         String getType = String.format("SELECT U.type FROM Users U WHERE U.name = '%s' AND U.password = '%s'", name, password);
         List<List<String>> userType = esql.executeQueryAndReturnResult(getType);

         for (List<String> row : userType) {
            for (String value : row) {
                if (value.trim().equals("customer")) {
                  System.out.println("You do not have access to this function as a customer.");
                  return; 
                }
            }
        }

         int userID = esql.executeQueryAndPrintResult(getUser);

         System.out.print("\tEnter the user ID: ");
         String enterID = in.readLine();
         System.out.println();

         String output = String.format("SELECT S.storeID FROM Store S WHERE S.managerID = '%s'", enterID);
         List<List<String>> storeManaged = esql.executeQueryAndReturnResult(output);
         System.out.println();
         System.out.println("List of stores that you manage");
         System.out.println();
         System.out.println("Store ID");
         for (List<String> row : storeManaged) {
            for (String value : row) {
               System.out.print(value + "\t");
            }
            System.out.println();
         }

         System.out.println();
         System.out.print("\tEnter the storeID: ");
         String getStore = in.readLine();
         System.out.println();

         String pList = String.format("SELECT DISTINCT P.productName FROM Product P, Store S WHERE P.storeID = '%s'", getStore);
         List<List<String>> products = esql.executeQueryAndReturnResult(pList);
         System.out.println();
         System.out.println("List of products");
         System.out.println();
         System.out.println("Product Name");
         for (List<String> row : products) {
            for (String value : row) {
               System.out.print(value + "\t");
            }
            System.out.println();
         }

         System.out.println();
         System.out.print("\tEnter the product name: ");
         String getProduct = in.readLine();
         System.out.println();

         System.out.print("\tEnter the # of units needed: ");
         String getUnits = in.readLine();

         String WID = " ";
         int num = 0;
         boolean checkInput = false;

         while (!checkInput) {
            System.out.print("\tEnter the warehouse ID to supply the request (1-5): ");
            try {
                WID = in.readLine();
                num = Integer.parseInt(WID);

                if (num >= 1 && num <= 5) {
                    checkInput = true; // Update checkInput if input is valid
                } else {
                    System.out.println("\tInvalid input. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("\tInvalid input. Please enter a valid integer.");
            }
        }

        System.out.println();
        System.out.print("\tPlacing supply request...");
        //Update productSupplyRequests
        String updateRecord = String.format("INSERT INTO ProductSupplyRequests (managerID, warehouseID, storeID, productName, unitsRequested) VALUES ('%s', '%s', '%s', '%s', '%s')", enterID, WID, getStore, getProduct, getUnits);
        esql.executeUpdate(updateRecord);

        System.out.print("Supply request has been placed.");
        System.out.println();

        //Show requests table
        String newReqTable = String.format("SELECT * FROM ProductSupplyRequests SP WHERE SP.managerID = '%s' ORDER BY SP.requestNumber DESC", enterID);
        System.out.println();
        System.out.println("Product Supply Requests");
        System.out.println();
        System.out.println("Request#\tmanagerID\twarehouseID\tstoreID\t\tproductName\t\tunitsRequested");
        List<List<String>> updatedReqTable = esql.executeQueryAndReturnResult(newReqTable);
        for (List<String> row : updatedReqTable) {
           for (String value : row) {
              System.out.print(value + "\t\t");
           }
           System.out.println();
        }

        System.out.println();


        //Show update 
        String updateUnits = String.format("UPDATE Product P SET numberOfUnits = numberOfUnits + '%s' WHERE P.storeID = '%s' AND P.productName = '%s'", getUnits, getStore, getProduct); 
        esql.executeUpdate(updateUnits);
        System.out.println ("Successfully updated number of units for " + getProduct + '.');
        System.out.println();
        System.out.print("Product inventory has been updated.");
        System.out.println();
        String newUpdate = String.format("SELECT DISTINCT * FROM Product P WHERE P.storeID = '%s' ORDER BY P.numberOfUnits DESC", getStore);
        System.out.println();
        System.out.println("Products");
        System.out.println();
        System.out.println("Store ID\tProduct Name\t\tNumber of Units\t\tPrice Per Unit");
        List<List<String>> updatedProduct = esql.executeQueryAndReturnResult(newUpdate);
        for (List<String> row : updatedProduct) {
           for (String value : row) {
              System.out.print(value + "\t\t");
           }
           System.out.println();
        }

      } catch(Exception e) {
         System.err.println(e.getMessage());
         }

   }

   /* They will be able to see orderID, customer name, storeID, productName, and date of order for each order. */
   public static void viewOrderInfo(Amazon esql) {
      try {
         System.out.println("Please enter your name and password to view order information of your managed store(s).");
         System.out.println();
         System.out.print("\tEnter name: ");
         String name = in.readLine();
         System.out.print("\tEnter password: ");
         String password = in.readLine();
         System.out.println();
         System.out.println("Getting your user ID...");
         System.out.println();

         String getUser = String.format("SELECT U.userID FROM Users U WHERE U.name = '%s' AND U.password = '%s'", name, password);
         System.out.println();

         String getType = String.format("SELECT U.type FROM Users U WHERE U.name = '%s' AND U.password = '%s'", name, password);
         List<List<String>> userType = esql.executeQueryAndReturnResult(getType);

         for (List<String> row : userType) {
            for (String value : row) {
                if (value.trim().equals("customer")) {
                  System.out.println("You do not have access to this function as a customer.");
                  return; 
                }
            }
        }

         int userID = esql.executeQueryAndPrintResult(getUser);

         System.out.print("\tEnter the user ID: ");
         String enterID = in.readLine();

         System.out.println();

         String getID = String.format("SELECT S.storeID FROM Store S WHERE S.managerID = '%s'", enterID);
         String getAdmin = "SELECT * FROM Store ORDER BY storeID ASC";

         List<List<String>> storeIDs = new ArrayList<>();

         if (enterID.equals("1")) {
            storeIDs = esql.executeQueryAndReturnResult(getAdmin); 
         }
         else {
            storeIDs = esql.executeQueryAndReturnResult(getID);
         }
        
         System.out.println();
         System.out.println("Order Information");
         System.out.println();

         for (List<String> srow : storeIDs) {
            String storeID = srow.get(0);
            String output = String.format("SELECT O.orderNumber, U.name, O.storeID, O.productName, O.orderTime FROM Orders O, Users U WHERE O.storeID = '%s' AND O.customerID = U.userID ORDER BY O.orderNumber DESC", storeID);
            List<List<String>> storeManaged = esql.executeQueryAndReturnResult(output);
      
            System.out.println("Order#\tCustomer\t\t\t\tStore ID\t\tProduct Name\t\tOrder Time");
            for (List<String> row : storeManaged) {
               for (String value : row) {
                  System.out.print(value + "\t");
               }
               System.out.println();
            }
            System.out.println();
      }

   } catch(Exception e) {
         System.err.println(e.getMessage());
      }

   }

}//end Amazon


